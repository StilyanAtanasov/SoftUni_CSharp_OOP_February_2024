﻿namespace _03._Telephony;

public interface ICaller
{
    void Call(string number);
}