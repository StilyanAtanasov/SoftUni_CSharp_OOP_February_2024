﻿namespace _03._Telephony;

public interface IBrowser
{
    void Browse(string website);
}