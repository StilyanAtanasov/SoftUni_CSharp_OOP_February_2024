﻿// ReSharper disable UnusedMemberInSuper.Global
namespace _06._Food_Shortage;

public interface IIdentifiable
{
    string Id { get; }
}