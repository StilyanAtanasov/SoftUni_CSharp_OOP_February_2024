﻿namespace _06._Food_Shortage;

public interface IBirthable
{
    string Birthdate { get; }
}