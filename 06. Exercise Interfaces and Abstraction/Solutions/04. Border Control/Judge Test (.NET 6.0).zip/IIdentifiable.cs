﻿namespace _04._Border_Control;

public interface IIdentifiable
{
    string Id { get; }
}