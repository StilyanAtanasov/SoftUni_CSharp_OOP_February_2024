﻿// ReSharper disable UnusedMemberInSuper.Global
namespace _05._Birthday_Celebrations;

public interface IIdentifiable
{
    string Id { get; }
}