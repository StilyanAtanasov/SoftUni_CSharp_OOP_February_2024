﻿namespace _05._Birthday_Celebrations;

public interface IBirthable
{
    string Birthdate { get; }
}