﻿namespace Farm;

public class StartUp
{
    static void Main()
    {
        // Sample Code Usage

        Puppy puppy = new Puppy();
        puppy.Eat();
        puppy.Bark();
        puppy.Weep();
    }
}