﻿namespace AuthorProblem;

[Author("Stilyan")]
public class StartUp
{
    [Author("Stilyan")]
    [Author("Stilyan")]
    public static void Main()
    {

    }
}