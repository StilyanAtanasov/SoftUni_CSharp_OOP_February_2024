﻿namespace _04._Wild_Farm.Models.Food;

public class Fruit : Food
{
    public Fruit(int foodQuantity) : base(foodQuantity) { }
}