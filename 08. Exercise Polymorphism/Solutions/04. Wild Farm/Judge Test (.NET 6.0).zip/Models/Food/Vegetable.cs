﻿namespace _04._Wild_Farm.Models.Food;

public class Vegetable : Food
{
    public Vegetable(int foodQuantity) : base(foodQuantity) { }
}