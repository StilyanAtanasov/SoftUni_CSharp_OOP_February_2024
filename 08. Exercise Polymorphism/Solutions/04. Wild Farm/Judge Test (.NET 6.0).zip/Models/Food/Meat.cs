﻿namespace _04._Wild_Farm.Models.Food;

public class Meat : Food
{
    public Meat(int foodQuantity) : base(foodQuantity) { }
}