﻿namespace _04._Wild_Farm.Models.Food;

public class Seeds : Food
{
    public Seeds(int foodQuantity) : base(foodQuantity) { }
}